﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        double volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Test");
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Lblraio_Click(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtraio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtraio.Focus();
            }
            else
            {
                if (raio<=0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtraio.Focus();
                }
            }
        }

        private void Txtaltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtaltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                e.Cancel = true;
            }
            else
            {
                if (altura<=0)
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            //limpar os dados
            txtaltura.Clear();
            txtraio.Clear();
            txtvolume.Clear();
            txtraio.Focus();
        }

        private void Btncalcular_BackgroundImageLayoutChanged(object sender, EventArgs e)
        {

        }

        private void Btncalcular_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtvolume.Text = volume.ToString("N2");
        }
    }
}
