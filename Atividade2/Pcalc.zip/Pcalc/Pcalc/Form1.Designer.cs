﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(461, 94);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(244, 26);
            this.txt1.TabIndex = 0;
            this.txt1.Validated += new System.EventHandler(this.Txt1_Validated);
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(461, 174);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(244, 26);
            this.txt2.TabIndex = 1;
            this.txt2.Validated += new System.EventHandler(this.Txt2_Validated);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(320, 100);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(78, 20);
            this.lbl1.TabIndex = 3;
            this.lbl1.Text = "Número 1";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(320, 177);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(78, 20);
            this.lbl2.TabIndex = 4;
            this.lbl2.Text = "Número 2";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(320, 259);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(82, 20);
            this.lbl3.TabIndex = 5;
            this.lbl3.Text = "Resultado";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(784, 100);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 38);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "Limpar";
            this.btn1.UseVisualStyleBackColor = true;
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(784, 174);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 35);
            this.btn2.TabIndex = 7;
            this.btn2.Text = "Sair";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(327, 358);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 33);
            this.btn3.TabIndex = 8;
            this.btn3.Text = "+";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(461, 358);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 33);
            this.btn4.TabIndex = 9;
            this.btn4.Text = "-";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(607, 358);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 33);
            this.btn5.TabIndex = 10;
            this.btn5.Text = "*";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(784, 358);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 33);
            this.btn6.TabIndex = 11;
            this.btn6.Text = "/";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.Btn6_Click);
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(461, 259);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(244, 26);
            this.txt3.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1238, 640);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.TextBox txt3;
    }
}

