﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        int lado1, lado2, lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtLado1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLado1, "");
            double valor1;

            if (!Double.TryParse(txtLado1.Text, out valor1))
            {
                errorProvider1.SetError(txtLado1, "Valor de A inválido");
            }
        }

        private void TxtLado2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtLado2, "");
            double valor2;

            if (!Double.TryParse(txtLado2.Text, out valor2))
            {
                errorProvider2.SetError(txtLado2, "Valor de B inválido");
            }
        }

        private void TxtLado3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtLado3, "");
            double valor3;

            if (!Double.TryParse(txtLado3.Text, out valor3))
            {
                errorProvider3.SetError(txtLado3, "Valor de C inválido");
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;

            if (!double.TryParse(txtLado1.Text, out valorA) ||
                !double.TryParse(txtLado2.Text, out valorB) ||
                !double.TryParse(txtLado3.Text, out valorC))
            {
                MessageBox.Show("Valores devem ser numéricos");
            }
            else
            {
                if (valorA < (valorB + valorC) && valorA >
                    Math.Abs(valorB - valorC) && valorB < (valorA + valorC)
                    && valorB > Math.Abs(valorA - valorC)
                    && valorC < (valorA + valorB) &&
                    valorC > Math.Abs(valorA - valorB))
                {
                    if (valorA == valorB && valorB == valorC)
                        MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triãngulo equilátero");
                    else
                    
                        if (valorA == valorB || valorA == valorC || valorC == valorB)
                            MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo isóceles");
                        else
                            MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} formam um triângulo escaleno");
                    
                }
                else
                    MessageBox.Show($"Os valores {valorA}, {valorB} e {valorC} não formam um triângulo");
            }

        }
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Text = "";
            txtLado2.Text = "";
            txtLado3.Text = "";

            txtLado1.Focus();
            lado1 = 0;
            lado2 = 0;
            lado3 = 0;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
