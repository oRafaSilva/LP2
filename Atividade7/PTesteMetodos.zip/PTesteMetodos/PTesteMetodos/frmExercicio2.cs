﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {
            if (String.Compare(txt1.Text, txt2.Text, true)==0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São Diferentes");
            }
        }

        private void BtnInserir1_Click(object sender, EventArgs e)
        {
            int metade = txt2.Text.Length / 2;

            txt2.Text = txt2.Text.Substring(0, metade) + 
            txt1.Text + txt2.Text.Substring(metade,
            txt2.Text.Length - metade);
            
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            int metade = txt1.Text.Length / 2;

            txt2.Text = txt1.Text.Insert(metade, "**");
        }
    }
}
