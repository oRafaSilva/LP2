﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (var i = 0; i<rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contador++;
                }
            }
            MessageBox.Show("A frase contém: " + contador + " números");
        }

        private void BtnPosicaoBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show($"a posição do primeiro caracter branco é: {posicao}");
        }

        private void BtnContaLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach (var c in rchtxtFrase.Text)
            {
                if (char .IsLetter(c))
                {
                    contador += 1;
                }
            }
            MessageBox.Show("a frase tem: " + contador + " letras");
        }
    }
}
