﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcalcINSS
{
    public partial class Form1 : Form
    {
        Double SalBruto, SalLiq, SalFam, AliqINSS, AliqIRPF, DescINSS, DescIRPF;

        private void btn1_Click(object sender, EventArgs e)
        {
            if (SalBruto <= 800.47)
            {
                txtAliqINSS.Text = "7,65%";
                DescINSS = 0.0765 * SalBruto;
            }
            else
                if (SalBruto <= 1050)
            {
                txtAliqINSS.Text = "8,65%";
                DescINSS = ((8.65 / 100) * SalBruto);
            }
            else
                    if (SalBruto <= 1400.77)
            {
                txtAliqINSS.Text = "9.00%";
                DescINSS = ((9 / 100) * SalBruto);
            }
            else
                        if (SalBruto <= 2801.56)
            {
                txtAliqINSS.Text = "11.00%";
                DescINSS = ((11 / 100) * SalBruto);
            }
            else
            {
                txtAliqINSS.Text = "Teto";
                DescINSS = 308.17;
            }

            if (SalBruto <= 1257.12) 
            {
                txtAliqIRPF.Text = "Isento";
                DescIRPF = 0;
            }
            else
                if (SalBruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15.00%";
                DescIRPF = ((15 / 100) * SalBruto);
            }
                else
            {
                txtAliqIRPF.Text = "27.5%";
                DescIRPF = ((27.5 / 100) * SalBruto);
            }

            if (SalBruto <= 435.52)
            {
                SalFam = QtdeFilho * 22.33;
            }
            else
                if (SalBruto <= 654.61)
            {
                SalFam = QtdeFilho * 15.74;
            }
            else
                SalFam = QtdeFilho * 0;

            SalLiq = SalBruto - DescINSS - DescIRPF + SalFam;
            txtSalLiq.Text = Convert.ToString(SalLiq);
            txtSalFam.Text = Convert.ToString(SalFam);
            txtDescINSS.Text = Convert.ToString(DescINSS);
            txtDescIRPF.Text = Convert.ToString(DescIRPF);
        }

        int QtdeFilho;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxNome_Validated(object sender, EventArgs e)
        {

        }

        private void mskbxSalBru_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxSalBru_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxSalBru.Text, out SalBruto))
            {
                MessageBox.Show("Salário bruto inválido!");
                mskbxSalBru.Focus();
            }
        }

        private void mskbxQtdeFilho_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(mskbxQtdeFilho.Text, out QtdeFilho))
            {
                MessageBox.Show("Informe um número inteiro!");
                mskbxQtdeFilho.Focus();
            }
        }
    }
}
