﻿
namespace PcalcINSS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalBru = new System.Windows.Forms.MaskedTextBox();
            this.mskbxQtdeFilho = new System.Windows.Forms.MaskedTextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(57, 48);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(105, 13);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Nome do funcionário";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(57, 104);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(66, 13);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Salário bruto";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(57, 158);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(86, 13);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Número de filhos";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(57, 285);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(73, 13);
            this.lbl4.TabIndex = 3;
            this.lbl4.Text = "Aliquota INSS";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(57, 340);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(74, 13);
            this.lbl5.TabIndex = 4;
            this.lbl5.Text = "Alíquota IRPF";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Location = new System.Drawing.Point(57, 396);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(73, 13);
            this.lbl6.TabIndex = 5;
            this.lbl6.Text = "Salário família";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Location = new System.Drawing.Point(57, 446);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(78, 13);
            this.lbl7.TabIndex = 6;
            this.lbl7.Text = "Salário Líquido";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Location = new System.Drawing.Point(416, 285);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(81, 13);
            this.lbl8.TabIndex = 7;
            this.lbl8.Text = "Desconto INSS";
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Location = new System.Drawing.Point(416, 340);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(80, 13);
            this.lbl9.TabIndex = 8;
            this.lbl9.Text = "Desconto IRPF";
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(196, 41);
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(144, 20);
            this.mskbxNome.TabIndex = 9;
            this.mskbxNome.Validated += new System.EventHandler(this.mskbxNome_Validated);
            // 
            // mskbxSalBru
            // 
            this.mskbxSalBru.Location = new System.Drawing.Point(196, 97);
            this.mskbxSalBru.Name = "mskbxSalBru";
            this.mskbxSalBru.Size = new System.Drawing.Size(144, 20);
            this.mskbxSalBru.TabIndex = 10;
            this.mskbxSalBru.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskbxSalBru_MaskInputRejected);
            this.mskbxSalBru.Validated += new System.EventHandler(this.mskbxSalBru_Validated);
            // 
            // mskbxQtdeFilho
            // 
            this.mskbxQtdeFilho.Location = new System.Drawing.Point(196, 151);
            this.mskbxQtdeFilho.Name = "mskbxQtdeFilho";
            this.mskbxQtdeFilho.Size = new System.Drawing.Size(144, 20);
            this.mskbxQtdeFilho.TabIndex = 11;
            this.mskbxQtdeFilho.Validated += new System.EventHandler(this.mskbxQtdeFilho_Validated);
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(196, 278);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(144, 20);
            this.txtAliqINSS.TabIndex = 12;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(196, 333);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(144, 20);
            this.txtAliqIRPF.TabIndex = 13;
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Location = new System.Drawing.Point(196, 389);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.Size = new System.Drawing.Size(144, 20);
            this.txtSalFam.TabIndex = 14;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(196, 439);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(144, 20);
            this.txtSalLiq.TabIndex = 15;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(543, 282);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(149, 20);
            this.txtDescINSS.TabIndex = 16;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(543, 337);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(149, 20);
            this.txtDescIRPF.TabIndex = 17;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(160, 207);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(104, 35);
            this.btn1.TabIndex = 18;
            this.btn1.Text = "Verifica desconto";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1457, 644);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.mskbxQtdeFilho);
            this.Controls.Add(this.mskbxSalBru);
            this.Controls.Add(this.mskbxNome);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBru;
        private System.Windows.Forms.MaskedTextBox mskbxQtdeFilho;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.Button btn1;
    }
}

