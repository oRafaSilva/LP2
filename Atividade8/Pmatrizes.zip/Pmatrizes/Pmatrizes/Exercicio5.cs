﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void Exercicio5_Load(object sender, EventArgs e)
        {

            string[] palavras = new string[2];
            int[] tamanho = new int[2];

            string auxiliar = "";

            for (int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o nome {i + 1}", "Entrada de dados");
                if (auxiliar == "")
                    i--;
                else
                {
                    palavras[i] = auxiliar;
                }

            }

            int auxFor = 0;

            foreach (string palavra in palavras)
            {
                int aux = 0;

                for (int i = 0; i < palavra.Length; i++)
                {
                    if (palavra[i] != ' ')
                    {
                        aux++;
                    }
                }
                tamanho[auxFor] = aux;
                auxFor++;

            }

            for (int i = 0; i < palavras.Length; i++)
            {
                string aux = $"O nome: {palavras[i]} tem {tamanho[i]} carecteres";
                lboxNomes.Items.Add(aux);
            }
        }
    }
}
