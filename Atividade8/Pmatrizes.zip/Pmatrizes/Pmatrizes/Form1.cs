﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for (var i=0; i< 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número de 20",
                    "Entrada de Dados");

                if (auxiliar == "")
                    return;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (var x in vetor)
                auxiliar += x + "\n"; 
            MessageBox.Show(auxiliar);
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            string auxiliar = "";
            string saida = "";
            for (var aluno = 0; aluno < 20; aluno++)
                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {nota+1}ª do {aluno+1}º ",
                    "Entrada de Dados");

                    if (auxiliar == "")
                        return;

                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Nota não válida");
                        nota--;
                    }
                    else
                        if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                        {
                        MessageBox.Show("Nota não válida");
                        }
                }
            for (var aluno = 0; aluno < 20; aluno++)
            {
                media = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
                saida = saida + $"Aluno {aluno} - Média: {media} \n";
                media = 0;
            }

                    MessageBox.Show(saida);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            ArrayList myAL = new ArrayList();
            myAL.Add("Ana");
            myAL.Add("André");
            myAL.Add("Débora");
            myAL.Add("Fátima");
            myAL.Add("João");
            myAL.Add("Janete");
            myAL.Add("Otávio");
            myAL.Add("Marcelo");
            myAL.Add("Pedro");
            myAL.Add("Thais");

            myAL.Remove("Otávio");
            string texto = "";
            foreach (var nome in myAL)
            {
                texto += nome + "\n";

            }
            MessageBox.Show(texto.ToString());
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            Exercicio5 form2 = new Exercicio5();
            form2.ShowDialog();
        }
    }
}
