﻿
namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPeso = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.msktxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.msktxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.btnLimp = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.msktxtIMC = new System.Windows.Forms.MaskedTextBox();
            this.lblIMC = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(347, 112);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(31, 13);
            this.lblPeso.TabIndex = 0;
            this.lblPeso.Text = "Peso";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(350, 284);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 1;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // msktxtPeso
            // 
            this.msktxtPeso.Location = new System.Drawing.Point(462, 112);
            this.msktxtPeso.Name = "msktxtPeso";
            this.msktxtPeso.Size = new System.Drawing.Size(194, 20);
            this.msktxtPeso.TabIndex = 2;
            this.msktxtPeso.Validated += new System.EventHandler(this.msktxtPeso_Validated);
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(347, 167);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(34, 13);
            this.lblAltura.TabIndex = 3;
            this.lblAltura.Text = "Altura";
            // 
            // msktxtAltura
            // 
            this.msktxtAltura.Location = new System.Drawing.Point(462, 166);
            this.msktxtAltura.Name = "msktxtAltura";
            this.msktxtAltura.Size = new System.Drawing.Size(194, 20);
            this.msktxtAltura.TabIndex = 4;
            this.msktxtAltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.msktxtAltura_MaskInputRejected);
            this.msktxtAltura.Validated += new System.EventHandler(this.msktxtAltura_Validated);
            // 
            // btnLimp
            // 
            this.btnLimp.Location = new System.Drawing.Point(462, 284);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(75, 23);
            this.btnLimp.TabIndex = 5;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = true;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(581, 284);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // msktxtIMC
            // 
            this.msktxtIMC.Location = new System.Drawing.Point(462, 216);
            this.msktxtIMC.Name = "msktxtIMC";
            this.msktxtIMC.Size = new System.Drawing.Size(194, 20);
            this.msktxtIMC.TabIndex = 7;
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Location = new System.Drawing.Point(347, 219);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(26, 13);
            this.lblIMC.TabIndex = 8;
            this.lblIMC.Text = "IMC";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1485, 844);
            this.Controls.Add(this.lblIMC);
            this.Controls.Add(this.msktxtIMC);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.msktxtAltura);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.msktxtPeso);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblPeso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.MaskedTextBox msktxtPeso;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.MaskedTextBox msktxtAltura;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.MaskedTextBox msktxtIMC;
        private System.Windows.Forms.Label lblIMC;
    }
}

