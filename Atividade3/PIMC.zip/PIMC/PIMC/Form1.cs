﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double resultado, peso, altura; 
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            resultado = peso / (altura * altura);
            msktxtIMC.Text = resultado.ToString();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            msktxtPeso.Text = "";
            msktxtAltura.Text = "";
            msktxtIMC.Text = "";

            msktxtPeso.Focus();
            resultado = 0;
            peso = 0;
            altura = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void msktxtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtPeso.Text, out peso))
            {
                MessageBox.Show("Insira o peso em kg!");
                msktxtPeso.Focus();
            }
        }

        private void msktxtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void msktxtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtAltura.Text, out altura))
            {
                MessageBox.Show("Insira a altura em metros!");
                msktxtAltura.Focus();
            }
        }
    }
}
